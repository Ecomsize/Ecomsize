/* Ajaxify v1 | Copyright (c) 2017 Elkfox Co Pty Ltd | https://elkfox.com | Project lead: George Butter | MIT License | https://github.com/Elkfox/Ajaxify */
ajaxify = function(e) {
    e = e || {};
  var textLoading = "AFFICHER PLUS";
    var a, n, t, l, o, i, s = e.linkParent || ".pagination",
        d = e.parentContainer || "#MainContent",
        c = e.endlessScrollContainer || ".EndlessScroll",
        r = e.endlessClickContainer || ".EndlessClick",
        f = e.endlessOffset || 0,
        h = e.ajaxinateContainer || ".Ajaxinate",
        p = e.ajaxinateLink || ".page a",
        u = e.fade || "fast",
        g = e.textChange || textLoading;
    $.loadMore = function() {
        i.length && $.ajax({
            type: "GET",
            dataType: "html",
            url: i,
            success: function(e) {
                "ajax" == l ? ($(h).not('[data-page="' + t + '"]').hide(), history.pushState({}, t, i)) : $(a).fadeOut(u);
                var o = $(e).find(n);
                $(o).appendTo($(n).parent()).hide().fadeIn(u), "endlessScroll" == l ? $.endlessScroll() : "ajax" == l ? $.ajaxinationClick() : "endlessClick" == l && $.endlessClick()
            }
        })
    }, $.endlessScroll = function() {
        o = "scroll load resize", $(window).on(o, function() {
            if (n = c, i = $(n + ":last-of-type " + a).attr("href"), l = "endlessScroll", $(a).text(g), $(n + ":last-of-type " + a).length) {
                var e = $(d).outerHeight(),
                    t = $(document).scrollTop() + $(window).height() + f;
                t > e && ($(window).off(o), $.loadMore())
            }
        })
    }, $.endlessClick = function() {
        $(a).on("click", function(e) {
            e.preventDefault(), o = "click", n = r, i = $(this).attr("href"), l = "endlessClick", $(a).text(g), $(a).off(o), $.loadMore()
        })
    }, $.ajaxinationClick = function() {
        $(a).on("click", function(e) {
            e.preventDefault(), o = "click", n = h, i = $(this).attr("href"), t = $(this).attr("data-number"), l = "ajax", $(n + '[data-page="' + t + '"]').length ? ($(n).not('[data-page="' + t + '"]').hide(), $(n + '[data-page="' + t + '"]').fadeIn(u), history.pushState({}, t, i)) : ($(a).off(o), $.loadMore()), $("html, body").animate({
                scrollTop: $(d).offset().top
            }, 300)
        })
    }, $(r).length && (a = s + " a", $.endlessClick()), $(h).length && (a = p, $.ajaxinationClick()), $(c).length && (a = s + " a", $.endlessScroll())
};